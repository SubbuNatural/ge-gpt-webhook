﻿using GeideaGPT.Services;
using Google.Cloud.Dialogflow.V2;
using Google.Protobuf;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Globalization;
using System.Text;

namespace GeideaGPT.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GeideaflowController : Controller
    {
        private static readonly JsonParser jsonParser = new JsonParser(JsonParser.Settings.Default.WithIgnoreUnknownFields(true));
        private readonly DialogflowService _dialogflowService;
        public GeideaflowController()
        {
            _dialogflowService = new DialogflowService();
        }
        [HttpPost("ask")]
        public async Task<IActionResult> AskDialogflow([FromBody] UserQuery request)
        {
            string response = await _dialogflowService.DetectIntentAsync(Guid.NewGuid().ToString(), request.Query);
            return Ok(new { reply = response });
        }
        [HttpPost]
        public async Task<IActionResult> GetWebhook()
        {
            try
            {
                WebhookRequest request;
                using (var reader = new StreamReader(Request.Body))
                {
                    var requestBody = await reader.ReadToEndAsync();
                    request = jsonParser.Parse<WebhookRequest>(requestBody);
                }
                var intentName = request.QueryResult.Intent.DisplayName;
                var response = new WebhookResponse();
                StringBuilder sb = new StringBuilder();
                switch (intentName)
                {
                    case "TicketsCreated":
                        var rest = GetTicketCountToday();
                        response.FulfillmentText = GetTicketCountToday();
                        break;
                    default:
                        response.FulfillmentText = "Sorry, I don't have an answer for that.";
                        break;
                }
                //response.FulfillmentText = sb.ToString();
                return Ok(response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        private string GetTicketCountToday()
        {
            var today = DateTime.Today;
            var tickets = System.IO.File.ReadAllLines("HelpDeskReport_5293_01-Apr-2025 071334.csv");
            int ticketCount = tickets.Count(ticket =>
            {
                var columns = ticket.Split(',');
                if (columns.Length > 1)
                {
                    string dateString = columns[1];
                    if (DateTime.TryParseExact(dateString, "d/M/yyyy",
                                               CultureInfo.InvariantCulture,
                                               DateTimeStyles.None,
                                               out DateTime ticketDate))
                    {
                        return ticketDate.Date == today;
                    }
                }
                return false;
            });
            return $"Total tickets created today: {ticketCount}";
        }
    }
    public class UserQuery
    {
        public string Query { get; set; }
    }
}
