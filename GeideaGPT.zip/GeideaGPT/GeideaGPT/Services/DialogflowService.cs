﻿using Google.Apis.Auth.OAuth2;
using Google.Cloud.Dialogflow.V2;

namespace GeideaGPT.Services
{
    public class DialogflowService
    {
        private readonly string _projectId;
        private readonly SessionsClient _sessionsClient;
        public DialogflowService()
        {
            var credentialPath = "geideapaybot-tnfp-651b2e5eb2e7.json";
            //var credentials = GoogleCredential.FromFile(credentialPath);

            GoogleCredential credential = null;
            using (Stream configstream = new FileStream(credentialPath, FileMode.Open))
            {
                credential = GoogleCredential.FromStream(configstream);
                _projectId = "geideapaybot-tnfp";
                _sessionsClient = new SessionsClientBuilder { Credential = credential }.Build();
            }
        }
        public async Task<string> DetectIntentAsync(string sessionId, string userInput)
        {
            try
            {
                var sessionName = new SessionName(_projectId, sessionId);
                var request = new DetectIntentRequest
                {
                    SessionAsSessionName = sessionName,
                    QueryInput = new QueryInput
                    {
                        Text = new TextInput { Text = userInput, LanguageCode = "en" }
                    }
                };
                var response = await _sessionsClient.DetectIntentAsync(request);
                return response.QueryResult.FulfillmentText;
            }
            catch (Exception ex)
            {
                return "Sorry, Failed to get response";
            }

        }
    }
}
